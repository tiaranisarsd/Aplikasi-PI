import { Sequelize } from "sequelize";

const db = new Sequelize('kata2818_db_kmic', 'kata2818_admin', 'XvH~},LB{RN_', {
    host: 'api.katarkayumanisapp.site',
    dialect: "mysql"
});

export default db;
